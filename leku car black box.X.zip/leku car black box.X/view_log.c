/*
 * File:   
 * Author: <NAME>
 *
 * Created on 1 December, 2023, 10:40 AM
 */


#include <xc.h>
#include "main.h"
#include "adc.h"
#include "clcd.h"
#include "eeprom.h"
#include "matrix_keypad.h"
#include "timer0.h"
#include"ext_eeprom.h"
#include"i2c.h"
#include"ds1307.h"

char view_array[10][11];
int i1, j1;
extern int log;
int view_ind, press;
extern char main_f;
extern char menu_ind, arrow_st;
int h, h2;
char set=1, wait2;
void view_log(char key) 
{
    //log
    if(log == -1)
    {
        clcd_print("  LOG IS EMPTY  ", LINE1(0));
        if(wait2++ == 250)
        {
            wait2 = 0;
            main_f = MENU;
        }
    }
    else
    {
        clcd_print("# TIME     EV SP", LINE1(0));
        if(set)
        {
            set=0;
            for (i1 = 0; i1 < log; i1++) 
            {
                for (j1 = 0; j1 < 10; j1++) 
                {
                    view_array[i1][j1] = read_ext_eeprom(i1 * 10 + j1);
                }
            }
        }
        clcd_putch(view_ind + '0', LINE2(0));
        clcd_putch(' ', LINE2(1));
        clcd_putch(view_array[view_ind][0], LINE2(2));
        clcd_putch(view_array[view_ind][1], LINE2(3));
        clcd_putch(':', LINE2(4));
        clcd_putch(view_array[view_ind][2], LINE2(5));
        clcd_putch(view_array[view_ind][3], LINE2(6));
        clcd_putch(':', LINE2(7));
        clcd_putch(view_array[view_ind][4], LINE2(8));
        clcd_putch(view_array[view_ind][5], LINE2(9));
        clcd_putch(' ', LINE2(10));
        clcd_putch(view_array[view_ind][6], LINE2(11));
        clcd_putch(view_array[view_ind][7], LINE2(12));
        clcd_putch(' ', LINE2(13));
        clcd_putch(view_array[view_ind][8], LINE2(14));
        clcd_putch(view_array[view_ind][9], LINE2(15));
        key = read_switches(LEVEL_CHANGE);

        if (key == MK_SW12) 
        {
            h++;
            if (h > 200) 
            {
                //h = 0;
                menu_ind = 0;
                arrow_st = 0;
                main_f = MENU;
                set=1;
                CLEAR_DISP_SCREEN;
            }
        } 
        else if (h < 200 && h != 0) 
        {
            h = 0;
            if (view_ind < log-1) 
            {
                view_ind++;
            }
        } 
        else 
        {
            h = 0;
        }
        if (key == MK_SW11) 
        {
            h2++;
            if (h2 > 200) 
            {
                //h2 = 0;
            }
        } 
        else if (h2 < 200 && h2 != 0) 
        {
            h2 = 0;
            if (view_ind > 0) 
            {
                view_ind--;
            }
        } 
        else 
        {
            h2 = 0;
        }
    }
}