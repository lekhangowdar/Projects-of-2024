/*
 * File:   
 * Author: <NAME>
 *
 * Created on 1 December, 2023, 10:40 AM
 */



#include <xc.h>
#include "main.h"
#include "clcd.h"

extern int log;
unsigned char wait1;
extern char main_f;

void clear_log(char key)
{
    //logic for clear
    log = -1;
    clcd_print("   LOG CLEARED  ",LINE1(0));
    clcd_print("  SUCCESSFULLY  ",LINE2(0));
    if(wait1++ == 250)
    {
        wait1 = 0;
        main_f = MENU;
        CLEAR_DISP_SCREEN;
    }
}
