/*
 * File:   
 * Author: <NAME>
 *
 * Created on 1 December, 2023, 10:40 AM
 */


#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"


extern unsigned char speed,sp1,sp2,ev_ind;
extern unsigned char ev[][3],time[9];
extern char main_f,key,wait_f;

void dashboard()
{
    //display logic
    clcd_print("  TIME    EV  SP", LINE1(0));
    clcd_print(time, LINE2(0));
    clcd_print(ev[ev_ind], LINE2(10));
    clcd_putch(sp1, LINE2(14));
    clcd_putch(sp2, LINE2(15));
    if(key == MK_SW11)
    {
        CLEAR_DISP_SCREEN;
        main_f = PASSWORD;
    }
}


