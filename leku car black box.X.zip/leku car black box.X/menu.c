/*
 * File:   
 * Author: <NAME>
 *
 * Created on 1 December, 2023, 10:40 AM
 */
//                        0    1    2    3    4    5    6    7    8    9    10   11   12   13
//unsigned char ev[][3]={"ON","GR","GN","G1","G2","G3","G4","G5","_C","VL","DL","CL","ST","CP"};

#include <xc.h>
#include "main.h"
#include "clcd.h"
#include "matrix_keypad.h"

unsigned char menu_op[5][17]={"  View Log     ","  Download Log ","  Clear Log    ","  Set Time     ","  Change Pswd  "};
unsigned char menu_ind,arrow_st;
extern unsigned char ev_ind;
extern char main_f, menu_f;
unsigned int time2,time1; /*varaible to check for short/long press*/


void menu(char menu_key)
{
    //logic for menu
    clcd_print(menu_op[menu_ind],LINE1(1));
    clcd_print(menu_op[menu_ind+1],LINE2(1));
    if(arrow_st == 0)
    {
        clcd_putch('*',LINE1(0));
        clcd_putch(' ',LINE2(0));
    }
    else
    {
        clcd_putch(' ',LINE1(0));
        clcd_putch('*',LINE2(0));
    }
    if(menu_key == MK_SW11)
    {
        time1++;    /*increment the time if the key is pressed*/
        if(time1 > 200)  /*check for long press*/
        {
            time1=0;
            main_f = MENU_ENTER;
            CLEAR_DISP_SCREEN;
            menu_f = menu_ind + arrow_st;
            ev_ind = menu_f + 9;
        }
    }
    else if(time1 < 200 && time1 != 0) /*check for short press*/
    {
        time1 = 0;  /*reset the time*/
        if(arrow_st == 1)
            arrow_st = 0;
        else if(menu_ind > 0)
            menu_ind--;  
    }
    else
    {
        time1 = 0;  /*reset the time to avoid extra count*/
    }
    if(menu_key == MK_SW12)
    {
        time2++;    /*increment the time if the key is pressed*/
        if(time2 > 200)/*check for long press*/
        {
            time2=0;
            main_f = DASHBOARD;
            CLEAR_DISP_SCREEN;
        }
    }
    else if(time2 < 200 && time2 != 0) /*check for short press*/
    {
        time2 = 0;  /*reset the time*/
        if(arrow_st == 0)    //">"   = 00111110   //10101011  //01111110 = "->"
            arrow_st = 1;
        else if (menu_ind < 3)
            menu_ind++;  
    }
    else
    {
        time2 = 0;  /*reset the time to avoid extra count*/
    }
}
